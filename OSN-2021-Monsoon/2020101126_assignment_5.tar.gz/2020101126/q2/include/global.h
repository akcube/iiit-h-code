#include "matchsim.h"

static const int num_zones = 3;

extern struct timespec start;
extern Match MatchInfo;

extern int spectating_time;
extern int num_groups;
extern int num_chances;
