#ifndef __COURSESIM_GLOBALS
#define __COURSESIM_GLOBALS

extern int num_students;
extern int num_labs;
extern int num_courses;

#endif