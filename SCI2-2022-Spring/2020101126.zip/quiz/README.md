# Science 2 Quiz 1

## Q1 
Run using `python3 q1.py`. Generates a 3d-plot of 4 points who's coordinates were generated randomly and which satisfy the given constraints.

## Q2
Run using `python3 q2.py`. Computes the lennard jones formula on the pairwise set of points and outputs their sum. 
